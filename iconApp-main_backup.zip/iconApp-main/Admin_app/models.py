from django.db import models
from icon.models import Icon, IconTeam
from games.models import Game
from games.models import Platform
from IGL_account.models import User
import pytz


# Create your models here.


class TournamentFormate(models.Model):
    """ A class is used to represent the Tournament Formate"""
    type = models.CharField(max_length=256, null=True, blank=True)

    def __str__(self):
        return self.type


class MyTimezoneTableIn(models.Model):
    ALL_TIMEZONES = sorted((item, item) for item in pytz.all_timezones)
    tz_name = models.CharField(choices=ALL_TIMEZONES, max_length=65)

    def __str__(self):
        return self.tz_name


class TournamentLengthIn(models.Model):
    hour = models.CharField(max_length=51, null=True, blank=True)

    def __str__(self):
        return self.hour


class TournamentSetupIn(models.Model):
    """ A class is used to represent the Tournament setup """
    ALL_TIMEZONES = sorted((item, item) for item in pytz.all_timezones) 

    CHECKED_IN_CHOICES = (
        ('yes', 'yes'),
        ('no', 'no'),
    )

    TEAM_EVENT = (
        ('yes', 'yes'),
        ('no', 'no'),
    )

    THIRD_GAME_CHOICES = (
        ('yes', 'yes'),
    )

    PARTICIPANT_PLACEMENT_CHOICES = (
        ('Autofill', 'Autofill'),
    )

    name = models.CharField(max_length=151, unique=True)
    tournament_host = models.ForeignKey(Icon, on_delete=models.PROTECT)
    platform = models.ManyToManyField(Platform, blank=True)
    game = models.ManyToManyField(Game, blank=True)
    Tournament_start_date = models.DateField()
    Tournament_start_time = models.TimeField()
    timezone = models.CharField(choices=ALL_TIMEZONES, max_length=65)
    checked_in_at = models.CharField(max_length=3, choices=CHECKED_IN_CHOICES)
    registration_open_date = models.DateTimeField()
    registration_close_date = models.DateTimeField()
    team_event = models.CharField(max_length=8, choices=TEAM_EVENT)
    max_players_team = models.PositiveSmallIntegerField()
    tournament_structure = models.ForeignKey(TournamentFormate, on_delete=models.PROTECT)
    max_player_participants = models.PositiveIntegerField()
    tournament_open_to = models.ForeignKey(IconTeam, on_delete=models.PROTECT)
    is_featured = models.BooleanField(default=False)
    entry_fee = models.PositiveIntegerField()
    third_place_game = models.CharField(max_length=3, choices=THIRD_GAME_CHOICES, null=True, blank=True)
    participants_placement = models.CharField(max_length=8, choices=PARTICIPANT_PLACEMENT_CHOICES, null=True, blank=True)
    tournament_length = models.ForeignKey(TournamentLengthIn, on_delete=models.PROTECT, null=True, blank=True)
    first_place = models.IntegerField(null=True, blank=True)
    second_place = models.IntegerField(null=True, blank=True)
    third_place = models.IntegerField(null=True, blank=True)
    fourth_place = models.IntegerField(null=True, blank=True)
    fifth_place = models.IntegerField(null=True, blank=True)
    first_prize_image = models.TextField(null=True, blank=True)
    second_prize_image = models.TextField(null=True, blank=True)
    third_prize_image = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name


class AddIcon(models.Model):
    first_name = models.CharField(max_length=150, null=True, blank=True)
    last_name = models.CharField(max_length=150, null=True, blank=True)
    email = models.EmailField(max_length=50, null=True, blank=True, unique=True)
    mobile_number = models.CharField(max_length=100)
    biography = models.CharField(max_length=255, null=True, blank=True)
    join_team_cta = models.CharField(max_length=255, null=True, blank=True)
    igl_team_name = models.CharField(max_length=150, null=True, blank=True)
    team_header_image = models.TextField(null=True, blank=True)
    team_icon = models.TextField(null=True, blank=True)
    icon_portrait_image = models.TextField( null=True, blank=True)
    hype_videos = models.TextField(null=True, blank=True)
    display_video = models.TextField(null=True, blank=True)
    platform = models.ForeignKey(Platform, on_delete=models.PROTECT, null=True, blank=True)
    games = models.ManyToManyField(Game, related_name="addicons")

    def __str__(self):
        return self.first_name


class BlogCategory(models.Model):
    """ A class is used to represent the Blog category module """
    category = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return self.category


class BlogPost(models.Model):
    """ A class is used to represent the Blog post module """
    post_title = models.CharField(max_length=255, null=True, blank=True, unique=True)
    publish_datetime = models.DateTimeField(null=True, blank=True)
    category = models.ForeignKey(BlogCategory, on_delete=models.PROTECT)
    featured_image = models.TextField(null=True, blank=True)
    draft = models.BooleanField(null=True, blank=True)
    schedule = models.BooleanField(null=True, blank=True)
    publish = models.BooleanField(null=True, blank=True)
    post_text = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.post_title


class VideoManagement(models.Model):
    """ A class is used to represent the Blog post module """
    position_one = models.TextField(null=True, blank=True)
    position_two = models.TextField(null=True, blank=True)
    position_three = models.TextField(null=True, blank=True)
    library_one = models.TextField(null=True, blank=True)
    library_two = models.TextField(null=True, blank=True)
    library_three = models.TextField(null=True, blank=True)
    library_four = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.position_one


class BusinessType(models.Model):
    business_type = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.business_type


class PartnerBox(models.Model):
    company_name = models.CharField(max_length=255, null=True, blank=True, unique=True)
    type = models.ForeignKey(BusinessType, on_delete=models.PROTECT)
    contact_number = models.CharField(max_length=50, null=True, blank=True)
    email = models.EmailField(null=True, blank=True)
    partner_thumbnail = models.TextField(null=True, blank=True)
    page_header = models.TextField(null=True, blank=True)
    video_one = models.TextField(null=True, blank=True)
    video_two = models.TextField(null=True, blank=True)
    video_three = models.TextField(null=True, blank=True)
    video_four = models.TextField(null=True, blank=True)
    partner_description = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.company_name


class UserManagement(models.Model):
    username = models.ForeignKey(User, on_delete=models.PROTECT)
    code_of_conduct_warning = models.BooleanField(default=False, null=True, blank=True)
    chat_forum_warning = models.BooleanField(default=False, null=True, blank=True)
    adjudication_warning = models.BooleanField(default=False, null=True, blank=True)
    message = models.TextField(null=True, blank=True)

    def __str__(self):
        return str(self.username)


class UserManagementVanquishing(models.Model):
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    code_of_conduct_violation = models.BooleanField(default=False, null=True, blank=True)
    chat_forum_violation = models.BooleanField(default=False, null=True, blank=True)
    excessive_Adjudication = models.BooleanField(default=False, null=True, blank=True)
    message = models.TextField(null=True, blank=True)

    def __str__(self):
        return str(self.username)

"""import required module"""
import random
import logging
from django.contrib.auth import authenticate
from django.contrib.auth.models import Group
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from rest_framework.views import APIView
from rest_framework import generics, viewsets, routers
from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from iconApi.settings import default
from Admin_app.permissions import GamePlayAdminPermissions, SuperAdminPermissions, IconAdminPermissions, OperationAdminPermissions, UserAdminPermissions
from .serializers import UserOtpSerializer, AdminLoginSerializer, AdminProfileSerializer, AdminRegistrationSerializer, BlogPostSerializer, \
TournamentSetupSerializer, AddIconSerializers, TournamentFormateSerializer, AddIconSerializer, BlogCategorySerializer, BlogPostSerializer, \
VideoManagementSerializer, TournamentLengthSerializer, TournamentSetupSerializers, PartnerBoxSerializer, BusinessTypeSerializer, UserManagementSerializer, UserManagementVanquishingSerializer, GetIglUsersListSerializer
from .models import TournamentSetupIn, TournamentFormate, AddIcon, TournamentLengthIn, BlogCategory, BlogPost, VideoManagement, PartnerBox, BusinessType, UserManagement, UserManagementVanquishing
from IGL_account.renderers import UserRenderer
from IGL_account.models import User
# Create your views here.


logger = logging.getLogger(__name__)

#Craete Default Router

router = routers.DefaultRouter()

def get_tokens_for_user(user):
    """Generate Token Manually"""
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class UserOtpView(APIView):
    """To perform the Otp operation sending on mail"""
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        try:
            email = request.data.get('email')
            is_verified_status = False
            if User.objects.filter(email=email).exists():
                serializer = UserOtpSerializer(data=request.data)
                if email:
                    obj_user = User.objects.get(email=email)
                    is_verified_status = obj_user.is_varified
                if serializer.is_valid():
                    if is_verified_status:
                        return Response({"is_verified": is_verified_status}, status=status.HTTP_200_OK)
                    else:
                        email = serializer.data.get('email')
                        otp = random.randint(100000, 999999)
                        link = str(otp)
                        plaintext = "test email"
                        htmly = get_template('Admin_app/verification-mail.html')
                        otp_link = {'link': link}
                        subject, from_email, to = 'One time password', default.EMAIL_HOST_USER, email
                        text_content = plaintext
                        html_content = htmly.render(otp_link)
                        msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
                        msg.attach_alternative(html_content, "text/html")
                        msg.send()
                        return Response({"is_verified": is_verified_status, "otp": otp}, status=status.HTTP_200_OK)
            else:
                return Response({'message': 'Unable to send OTP with given credential'},
                                status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to send OTP with given credential"}, status=status.HTTP_404_NOT_FOUND)



class AdminLoginView(APIView):
    """To perform the Otp operation sending on mail
       :parm request: object to pass to state when request page/url requested the user"""
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        try:
            user = User.objects.get(email=request.data.get('email'))
            if user.groups.all().exists():
                serializer = AdminLoginSerializer(data=request.data)
                if serializer.is_valid():
                    email = serializer.data.get('email')
                    password = serializer.data.get('password')
                    user = authenticate(email=email, password=password)
                    if user is not None:
                        token = get_tokens_for_user(user)
                        return Response({'token': token, 'msg': 'Login Success'}, status=status.HTTP_200_OK)
                    else:
                        return Response({'errors': {'non_field_errors': ['Email or Password is not Valid']}},
                                        status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"status": False, "error": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to perform login operation with given credential"}, status=status.HTTP_404_NOT_FOUND)


class AdminProfileView(APIView):
    """To perform the Login operation for Admin User's
           :parm request: object to pass to state when request page/url requested the user"""
    permission_classes = [IsAuthenticated]
    renderer_classes = [UserRenderer]

    def get(self, request, format=None):
        try:
            usr_obj = User.objects.get(email=request.user)
            usr_obj.is_varified = True
            usr_obj.save()
            serializer = AdminProfileSerializer(request.user)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the Admin user Record"}, status=status.HTTP_404_NOT_FOUND)


class AdminRegistrationView(APIView):
    """To perform the Admin user registration
       :parm request: object to pass to state when request page/url requested the user"""
    permission_classes = (SuperAdminPermissions,)
    renderer_classes = [UserRenderer]

    # Create Admin user only by Super Admin user
    def post(self, request):
        try:
            get_group = request.user.groups.all().values_list('name', flat=True)
            if 'SUPER ADMIN' in get_group:
                group_name = request.data.get('group')
                serializer = AdminRegistrationSerializer(data=request.data)
                if serializer.is_valid():
                    user = serializer.save()
                    search_group = Group.objects.get(name=group_name)
                    user.groups.add(search_group)
                    token = get_tokens_for_user(user)
                    return Response({'token': token, 'msg': 'Registration Successful'}, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({'msg': 'Request user is not Super Admin'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to registered the user details"}, status=status.HTTP_400_BAD_REQUEST)



class MyRegisterTournaments(generics.GenericAPIView):

    def get(self, request, pk=None):
        user_id = pk
        if user_id is None:
            return Response({"message": "Please provide user_id"})
        return Response({"message": "No registered tournaments"})


class TournamentSetupAPI(generics.GenericAPIView):
    """To create new Tournament-Setup by Admin user
       :parm request: object to pass to state when request page/url requested the user"""
    serializer_class = TournamentSetupSerializer
    permission_classes = (GamePlayAdminPermissions,)

    def post(self, request):
        try:
            serializer = TournamentSetupSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({'msg': 'Tournament setup successfully', 'data': serializer.data},
                                status=status.HTTP_200_OK)
            return Response({'msg': serializer.errors}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({'msg': 'Unable to create Tournament setup'}, status=status.HTTP_404_NOT_FOUND)

    def get(self, request, pk=None):
        try:
            platform_id = pk
            if platform_id is not None:
                tournament_data = TournamentSetupIn.objects.filter(platform=platform_id)
                serializer = TournamentSetupSerializers(tournament_data, many=True)
                return Response({'message': serializer.data}, status=status.HTTP_200_OK)
            tournament_data = TournamentSetupIn.objects.all()
            serializer = TournamentSetupSerializers(tournament_data, many=True)
            return Response({'message': serializer.data}, status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({'message': 'Unable to fetch Tournament details!'}, status=status.HTTP_404_NOT_FOUND)


class TournamentDetailsAPI(generics.GenericAPIView):
    """To fetch the details for all tournament list
       :parm request: object to pass to state when request page/url requested the user"""
    def get(self, request):
        data = TournamentSetupIn.objects.all()
        serializer = TournamentSetupSerializers(data, many=True)
        return Response({'data': serializer.data}, status=status.HTTP_200_OK)


class TournamentIsFeaturedAPI(generics.GenericAPIView):
    """To fetch list of all featured tournament
           :parm request: object to pass to state when request page/url requested the user"""
    permission_classes = [IsAuthenticated,]

    def get(self, request):
        tournament_data_all = TournamentSetupIn.objects.filter(is_featured=True)
        serializer = TournamentSetupSerializers(tournament_data_all, many=True)
        return Response({'message': serializer.data}, status=status.HTTP_200_OK)


class TournamentFormateAPI(generics.GenericAPIView):
    """To fetch the details of Tournament format
       :parm request: object to pass to state when request page/url requested the user"""
    serializer_class = TournamentFormateSerializer
    permission_classes = (GamePlayAdminPermissions,)

    def get(self, request):

        tournament_formate_data = TournamentFormate.objects.all()
        serializer = TournamentFormateSerializer(tournament_formate_data, many=True)
        return Response({"data": serializer.data}, status=status.HTTP_200_OK)


class TournamentLengthViewSets(viewsets.ModelViewSet):
    """To perform all operation for changes in Tournament length
           :parm request: object to pass to state when request page/url requested the user"""
    queryset = TournamentLengthIn.objects.all()
    serializer_class = TournamentLengthSerializer


router.register('tournament_length', TournamentLengthViewSets)


class AddIconAPI(generics.GenericAPIView):
    """To perform the Add Icon operation for Admin user
       :parm request: object to pass to state when request page/url requested the user"""
    serializer_class = AddIconSerializer
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """Create List of record for AddICon object"""
        try:
            serializer = AddIconSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({'data': serializer.data}, status=status.HTTP_200_OK)
            return Response({'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({'message': 'Unable to perform add icon operation'}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request):

        """return a list of all Icon objects
                :parm request:object to pass state,WHEN page/url requested by user.
                                    """
        icon_data = AddIcon.objects.all()
        serializer = AddIconSerializers(icon_data, many=True)
        return Response({'data': serializer.data}, status=status.HTTP_200_OK)


class IconDetailsAPI(generics.GenericAPIView):
    """To fetch the details of icons by ID bases or all icon objects details"""

    def get(self, request, pk=None):
        try:
            team_page_id = pk
            if team_page_id:
                team_page_data = AddIcon.objects.get(id=team_page_id)
                serializer = AddIconSerializers(team_page_data)
                return Response({'data': serializer.data}, status=status.HTTP_200_OK)
            team_page_data = AddIcon.objects.all()
            serializer = AddIconSerializers(team_page_data, many=True)
            return Response({'data': serializer.data}, status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('Information comming',e)
            return Response({'message': "Unable to get details of team page"}, status=status.HTTP_400_BAD_REQUEST)


class BlogCategoryViewSet(viewsets.ModelViewSet):
    """To perform the all (GET, POST, DELETE, PUT, PATCH) operations for operational admin or super admin user"""
    permission_classes = (OperationAdminPermissions,)
    queryset = BlogCategory.objects.all()
    serializer_class = BlogCategorySerializer


router.register(r'blog_category', BlogCategoryViewSet, basename='blog_category')


class BlogPostViewSets(viewsets.ModelViewSet):
    """Class for perform all operation related with BlogPost model"""
    permission_classes = (OperationAdminPermissions,)
    queryset = BlogPost.objects.all()
    serializer_class = BlogPostSerializer


router.register(r'blog_post', BlogPostViewSets, basename='blog_post')


class VideoManagementViewSet(viewsets.ModelViewSet):
    """To perform the all (GET, POST, DELETE, PUT, PATCH) operations for video management module for super admin user"""
    permission_classes = (OperationAdminPermissions,)
    queryset = VideoManagement.objects.all()
    serializer_class = VideoManagementSerializer


router.register(r'video_management', VideoManagementViewSet, basename='video_management')


class PartnerBoxAPI(viewsets.ModelViewSet):
    """To perform the all (GET, POST, DELETE, PUT, PATCH) operations for Partner box module for super admin user"""
    permission_classes = (OperationAdminPermissions,)
    queryset = PartnerBox.objects.all()
    serializer_class = PartnerBoxSerializer


router.register(r'partner_box', PartnerBoxAPI, basename='partner_box')


class BusinessTypeGetAPI(generics.GenericAPIView):

    def get(self, request):
        data = BusinessType.objects.all()
        serializer = BusinessTypeSerializer(data, many=True)
        return Response({"data": serializer.data}, status=status.HTTP_200_OK)


class UserManagementAPI(viewsets.ModelViewSet):
    permission_classes = (UserAdminPermissions,)
    queryset = UserManagement.objects.all()
    serializer_class = UserManagementSerializer


router.register(r'user_management', UserManagementAPI, basename='user_management')


class UserManagementVanquishingAPI(viewsets.ModelViewSet):
    permission_classes = (UserAdminPermissions,)
    queryset = UserManagementVanquishing.objects.all()
    serializer_class = UserManagementVanquishingSerializer


router.register(r'user_management_vanquishing', UserManagementVanquishingAPI, basename='user_management_vanquishing')



class PartnerBoxGetAPI(generics.GenericAPIView):

    def get(self, request, pk=None):

        partner_id = pk
        if partner_id:
            data = PartnerBox.objects.get(id=partner_id)
            serializer = PartnerBoxSerializer(data)
            return Response({"data": serializer.data}, status=status.HTTP_200_OK)
        data = PartnerBox.objects.all()
        serializer = PartnerBoxSerializer(data, many=True)
        return Response({"data": serializer.data}, status=status.HTTP_200_OK)


class BlogPostGetAPI(generics.GenericAPIView):

    def get(self, request, pk=None):

        blog_id = pk
        if blog_id:
            data = BlogPost.objects.get(id=blog_id)
            serializer = BlogPostSerializer(data)
            return Response({"data": serializer.data}, status=status.HTTP_200_OK)
        data = BlogPost.objects.all()
        serializer = BlogPostSerializer(data, many=True)
        return Response({"data": serializer.data}, status=status.HTTP_200_OK)


class GetUsersDetails(generics.GenericAPIView):
    serializer_class = GetIglUsersListSerializer

    def get(self, request):
        users = User.objects.all()
        serializer = GetIglUsersListSerializer(users, many=True)
        return Response({'data': serializer.data}, status=status.HTTP_200_OK)

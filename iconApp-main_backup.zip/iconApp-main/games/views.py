"""Import Required Module"""
import logging
from rest_framework.response import Response
from rest_framework import generics
from rest_framework import status
from django.shortcuts import render
from IGL_account.models import User
from .serializer import PlatformSerializer, GameSerializer, TournamentSerializer, StageTypeSerializer, StageSerializer, \
    GroupSerializer, RoundSerializer, MatchSerializer, MatchParticipantSerializer, TrophyCategorySerializer, \
    BadgesCategorySerializer, UserBadgesSerializer
from .models import Platform, Game, Tournament, StageType, Stage, Group, Round, Match, MatchParticipant, BadgesCategory, \
    TrophyCategory, UserBadges


logger = logging.getLogger(__name__)


# Create your views here.

class PlatformAPI(generics.GenericAPIView):
    serializer_class = PlatformSerializer

    def get(self, request, pk=None):
        """return a list of all StageType for specfic Platform
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to Platform id.
             """
        platform_id = pk
        try:
            if platform_id is not None:
                platform = Platform.objects.get(id=platform_id)
                serializer = PlatformSerializer(platform)
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
            platform = Platform.objects.all()
            serializer = PlatformSerializer(platform, many=True)
            return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('platform error Information incoming!', e)
            return Response({"message": "Unable to create platform"}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        """Create List of record for Platform
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = PlatformSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('error with platform create Information incoming!', e)
            return Response({"message": "Unable to create platform"}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """delete a single record for Platform,when request page/url requested the user
             :params pk pass the  Platform record id"""
        platform = Platform(pk)
        platform.delete()
        return Response({"msg": "Platform is deleted"})


class GameAPI(generics.GenericAPIView):
    serializer_class = GameSerializer

    def post(self, request):
        """Create List of record for Game
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = GameSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('game error Information incoming!', e)
            return Response({"message": "Unable to create Game"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all StageType for specfic Game
             :parm request:object to pass state,WHEN page/url requested by user.
             parm pk:pass to Tournament id.
                """
        platform_id = pk
        try:
            if platform_id is not None:
                games = Game.objects.filter(platforms__in=[platform_id])
                serializer = GameSerializer(games, many=True)
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
            games = Game.objects.all()
            serializer = GameSerializer(games, many=True)
            return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('game error Information incoming!', e)
            return Response({"message": "Unable to get the details of Game"}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """delete a single record for Game,when request page/url requested the user
                             :params pk pass the  Game record id"""
        game = Game(pk)
        game.delete()
        return Response({"msg": "game is deleted"})


class TournamentAPI(generics.GenericAPIView):
    serializer_class = TournamentSerializer

    def post(self, request):
        """Create List of record for Tournament
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = TournamentSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('tournament error Information incoming!', e)
            return Response({"message": "Unable to create the Tournament details"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all StageType for specfic Tournament
            :parm request:object to pass state,WHEN page/url requested by user.
             parm pk:pass to Tournament id.
                """
        tournament_id = pk
        try:
            if tournament_id is not None:
                tournament = Tournament.objects.get(id=tournament_id)
                serializer = TournamentSerializer(tournament)
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
            tournament = Tournament.objects.all()
            serializer = TournamentSerializer(tournament, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Tournament Information incoming!', e)
            return Response({"message": "No tournament registered"}, status=status.HTTP_400_BAD_REQUEST)


class StageTypeAPI(generics.GenericAPIView):
    serializer_class = StageTypeSerializer

    def post(self, request):
        """Create List of record for StageType
         :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = StageTypeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('stage type error Information incoming!', e)
            return Response({"message": "Unable to create stage types"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all StageType for specfic StageType
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to StageType id.
            """
        stageType_id = pk
        try:
            if stageType_id  is not None:
                stageType  = StageType.objects.get(id=stageType_id)
                serializer = StageTypeSerializer(stageType)
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
            stageType = StageType.objects.all()
            serializer = StageTypeSerializer(stageType, many=True)
            return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('stage type error Information incoming!', e)
            return Response({"message": "Unable to get the details of stage type"}, status=status.HTTP_400_BAD_REQUEST)


class StageAPI(generics.GenericAPIView):
    serializer_class = StageSerializer

    def post(self, request):
        """Create List of record for Stage
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = StageSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('stage error Information incoming!', e)
            return Response({"message": "Unable to update the Team member registration"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all Round for specfic Stage
          :parm request:object to pass state,WHEN page/url requested by user.
          parm pk:pass to Stage id.
          """
        stage_id = pk
        try:
            if stage_id  is not None:
                stage = Stage.objects.get(id=stage_id)
                serializer = StageSerializer(stage)
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
            stage = Stage.objects.all()
            serializer = StageSerializer(stage, many=True)
            return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('stage get error Information incoming!', e)
            return Response({"message": "Unable to find team member details"}, status=status.HTTP_400_BAD_REQUEST)


class GroupAPI(generics.GenericAPIView):
    serializer_class = GroupSerializer

    def post(self, request):
        """Create List of record for Group
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = GroupSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('group Information incoming!', e)
            return Response({"message": "Unable to create group"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all Round for specfic Group
        :parm request:object to pass state,WHEN page/url requested by user.
        parm pk:pass to Match id.
            """
        group_id = pk
        try:
            if group_id  is not None:
                group = Group.objects.get(id=group_id) 
                serializer = GroupSerializer(group)
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
            group = Group.objects.all()
            serializer = GroupSerializer(group, many=True)
            return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('group Information incoming!', e)
            return Response({"message": "Unable to get the group details"}, status=status.HTTP_400_BAD_REQUEST)


class RoundAPI(generics.GenericAPIView):
    serializer_class = RoundSerializer

    def post(self, request):
        """Create List of record for Round
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = RoundSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to define the Round"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all Round for specific Round
        :parm request:object to pass state,WHEN page/url requested by user.
        parm pk:pass to Match id.
            """
        round_id = pk
        try:
            if round_id is not None:
                round  = Round.objects.get(id=round_id)
                serializer = RoundSerializer(round)
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
            round = Round.objects.all()
            serializer = RoundSerializer(round, many=True)
            return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to get Round details"}, status=status.HTTP_400_BAD_REQUEST)


class MatchAPI(generics.GenericAPIView):
    serializer_class = MatchSerializer

    def post(self, request):
        """Create List of record for Match
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = MatchSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to create Matches"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all Match for specfic Match
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to Match id.
            """
        match_id = pk
        try:
            if match_id  is not None:
                match  = Match.objects.get(id=match_id)
                serializer = MatchSerializer(match)
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
            match = Match.objects.all()
            serializer = MatchSerializer(match, many=True)
            return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to get Match details"}, status=status.HTTP_400_BAD_REQUEST)


class MatchParticipantAPI(generics.GenericAPIView):
    serializer_class = MatchParticipantSerializer

    def post(self, request):
        """Create List of record for MatchParticipant
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = MatchParticipantSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Match Information incoming!', e)
            return Response({"message": "Unable to create MatchParticipant for Matches"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all MatchParticipant for specfic MatchParticipant
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to MatchParticipant id.
            """
        matchParticipant_id = pk
        try:
            if matchParticipant_id is not None:
                matchParticipant = MatchParticipant.objects.get(id=matchParticipant_id)
                serializer = MatchParticipantSerializer(matchParticipant)
                return Response({"data": serializer.data})
            matchParticipant = MatchParticipant.objects.all()
            serializer = MatchParticipantSerializer(matchParticipant, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to get MatchParticipant details with matches"}, status=status.HTTP_400_BAD_REQUEST)


class TrophyCategoryAPI(generics.GenericAPIView):
    serializer_class = TrophyCategorySerializer

    def post(self, request):
        """Create List of record for TrophyCategory
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = TrophyCategorySerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('trophy category Information incoming!', e)
            return Response({"message": "Unable to create trophy category"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all TrophyCategory for specific TrophyCategory
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to TrophyCategory id.
            """
        trophyCategory_id = pk
        try:
            if trophyCategory_id is not None:
                trophyCategory = TrophyCategory.objects.get(id=trophyCategory_id)
                serializer = TrophyCategorySerializer(trophyCategory)
                return Response({"data": serializer.data})
            trophyCategory = TrophyCategory.objects.all()
            serializer = TrophyCategorySerializer(trophyCategory, many=True)
            return Response({"data": serializer.data})

        except Exception as e:
            logging.info('trophy Information incoming!', e)
            return Response({"message": "Unable to get the Trophy category details"}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk=id):
        """update a list of record for TrophyCategory,when request page/url requested the user
                       :params pk pass the  TrophyCategory record id"""

        try:
            user_id = pk
            user = TrophyCategory.objects.get(id=user_id)
            serializer = TrophyCategorySerializer(user, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"msg": "TrophyCategory badges is updated"})
        except Exception as e:
            logging.info('Trophy category Information incoming!', e)
            return Response({"message": "Unable to perform the update trophy category details"}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """delete a single record for TrophyCategory,when request page/url requested the user
            :params pk pass the  TrophyCategory record id"""
        trophy = TrophyCategory(pk)
        trophy.delete()
        return Response({"msg": "TrophyCategory badges is deleted"})


class BadgesCategoryAPI(generics.GenericAPIView):
    serializer_class = BadgesCategorySerializer

    def post(self, request):
        """Create List of record for BadgesCategory
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = BadgesCategorySerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except:
            logging.info('Information incoming!')
            return Response({"message": "Unable to create the BadgesCategory details"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all UserTrophyCase for specfic BadgesCategory
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to BadgesCategory id.
             """
        user_id = pk
        try:
            if user_id is not None:
                badgesCategory = BadgesCategory.objects.get(id=user_id)
                serializer = BadgesCategorySerializer(badgesCategory)
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
            badgesCategory = BadgesCategory.objects.all()
            serializer = BadgesCategorySerializer(badgesCategory, many=True)
            return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('badges category Information incoming!', e)
            return Response({"message": "Unable to get the BadgesCategory details"}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk=id):
        """update a list of record for BadgesCategory,when request page/url requested the user
            :params pk pass the  BadgesCategory record id"""
        try:
            user_id = pk
            badgesCategory = BadgesCategory.objects.get(id=user_id)
            serializer = BadgesCategorySerializer(badgesCategory, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"msg": "BadgesCategory badges is updated"})
        except Exception as e:
            logging.info('badges category Information incoming!', e)
            return Response({"message": "Unable to perform the update Badges category details"}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """delete a single record for BadgesCategory,when request page/url requested the user
                      :params pk pass the  BadgesCategory record id"""

        badges = BadgesCategory(pk)
        badges.delete()
        return Response({"msg": "BadgesCategory badges is deleted"})


class UserBadgesAPI(generics.GenericAPIView):
    serializer_class = UserBadgesSerializer

    def post(self, request):
        try:
            # user = User.objects.get(data=request.user)
            serializer = UserBadgesSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('badges category Information incoming!', e)
            return Response({"message": "Unable to perform the update Badges category details"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):

        """return a list of all user_badges for specific user_badges
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to user id.
            """
        try:
            user_id = pk
            if user_id  is not None:
                userBadges = UserBadges.objects.filter(user_id=user_id)
                if userBadges:
                    serializer = UserBadgesSerializer(userBadges, many=True)
                    return Response({"data": serializer.data},status=status.HTTP_200_OK)
                else:
                    return Response({"message": "Unable to get user details"},status=status.HTTP_400_BAD_REQUEST)

            userBadges = UserBadges.objects.all()
            serializer = UserBadgesSerializer(userBadges, many=True)
            return Response({"data": serializer.data},status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to get user badges details"},status=status.HTTP_400_BAD_REQUEST)


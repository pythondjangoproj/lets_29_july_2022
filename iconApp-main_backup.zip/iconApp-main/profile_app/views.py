"""import required module"""
import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.decorators import api_view
from django.shortcuts import render
from django.db.models import Q
from .serializers import UserPlatformSerializer, UserGameSerializer, UserMatchParticipantSerializer, \
    GetUserSubmitSerializer, IGLNotificationSerializer, GlobalIndexHierarchySerializer, \
    GlobalIndexSerializer, PGIUserSubmitSerializer, UserIGLNotificationSerializer, UserTrophyCaseSerializer, \
    CompleteProfileSerializer, CreateProfileSerializer,GetAllFriendSerializer,CompleteProfileUpdateSerializer, FriendRequestSerializer, AcceptFriendsRequestSerializer, UserListSerializer, CompletingProfileUpdateSerializer, FriendRequestSerializers
from .models import UserPlatform, UserGame, UserMatchParticipant, GetUserSubmit, IGLNotification, \
    GlobalIndexHierarchy, GlobalIndex, PGIUserSubmit, UserIGLNotification, UserTrophyCase, CompleteProfile, \
    FriendRequest
from IGL_account.renderers import UserRenderer
from IGL_account.models import User
from datetime import date
from games.models import Platform, Game, UserBadges, Friends

logger = logging.getLogger(__name__)


# Create your views here.


class UserPlatformAPI(generics.GenericAPIView):
    serializer_class = UserPlatformSerializer

    def post(self, request):
        """Create List of record for UserPlatform
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = UserPlatformSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('User Platform Information incoming!', e)
            return Response({"message": "Unable to create the user platform"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all Match for specific UserPlatform
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserPlatform id.
            """
        userPlatform_id = pk

        try:
            if userPlatform_id is not None:
                userPlatform = UserPlatform.objects.get(id=userPlatform_id)
                serializer = UserPlatformSerializer(userPlatform)
                return Response({"data": serializer.data})
            userPlatform  = UserPlatform.objects.all()
            serializer = UserPlatformSerializer(userPlatform, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of user platform "}, status=status.HTTP_400_BAD_REQUEST)


class UserGameAPI(generics.GenericAPIView):
    serializer_class = UserGameSerializer

    def post(self, request):
        """Create List of record for UserGame
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = UserGameSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('User game Information incoming!', e)
            return Response({"message": "Unable to create user Game"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all Match for specific UserGame
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserGame id.
            """

        user_id = pk
        try:
            if user_id is not None:
                userGame = UserGame.objects.get(id=user_id)
                serializer = UserGameSerializer(userGame)
                return Response({"data": serializer.data})
            userGame = UserGame.objects.all()
            serializer = UserGameSerializer(userGame, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('user game Information incoming!', e)
            return Response({"message": "Unable to create Game for registered user"}, status=status.HTTP_400_BAD_REQUEST)


class UserMatchParticipantAPI(generics.GenericAPIView):
    serializer_class = UserMatchParticipantSerializer

    def post(self, request):
        """Create List of record for UserMatchParticipant
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = UserMatchParticipantSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('User match Information incoming!', e)
            return Response({"message": "Unable to create match for user"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all Match for specific UserMatchParticipant
             :parm request:object to pass state,WHEN page/url requested by user.
                parm pk:pass to UserMatchParticipant id.
                    """
        user_id = pk
        try:
            if user_id is not None:
                userMatchParticipant = UserMatchParticipant.objects.get(id=user_id)
                serializer = UserMatchParticipantSerializer(userMatchParticipant)
                return Response({"data": serializer.data})
            userMatchParticipant = UserMatchParticipant.objects.all()
            serializer = UserMatchParticipantSerializer(userMatchParticipant, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to Get the details of user match participants"}, status=status.HTTP_400_BAD_REQUEST)


class UserTrophyCaseAPI(generics.GenericAPIView):
    serializer_class = UserTrophyCaseSerializer

    def get(self, request, pk=None):
        """return a list of all UserTrophyCase for specfic UserTrophyCase
                :parm request:object to pass state,WHEN page/url requested by user.
                parm pk:pass to UserTrophyCase id.
                """

        userTrophyCase_id = pk
        try:
            if userTrophyCase_id is not None:
                userTrophyCase = UserTrophyCase.objects.get(id=userTrophyCase_id)
                serializer = UserTrophyCaseSerializer(userTrophyCase)
                return Response({"data": serializer.data})
            userTrophyCase = UserTrophyCase.objects.all()
            serializer = UserTrophyCaseSerializer(userTrophyCase, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('user trophy Information incoming!', e)
            return Response({"message": "Unable to get the UserTrophyCase details"}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        """Create List of record for UserTrophyCase
              :parm request:object to pass to state when request page/url requested the user
              """
        try:
            serializer = UserTrophyCaseSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('user trophy Information incoming!', e)
            return Response({"message": "Unable to create the UserTrophyCaseSerializer details"}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """delete a single record for BadgesCategory,when request page/url requested the user
                      :params pk pass the  UserTrophyCase record id"""

        usercase = UserTrophyCase(pk)
        usercase.delete()
        return Response({"msg": "UserTrophyCase  is deleted"})


class GetUserSubmitAPI(generics.GenericAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [IsAuthenticated]
    serializer_class = GetUserSubmitSerializer

    def post(self, request):
        """Create List of record for GetUserSubmit
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = GetUserSubmitSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('User Platform Information incoming!', e)
            return Response({"message": "Unable to submit profile details of user"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all Match for specific user profile
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserDetails id.
            """
        user_id = pk

        try:
            if user_id is not None:
                user = GetUserSubmit.objects.get(id=user_id)
                serializer = GetUserSubmitSerializer(user)
                return Response({"data": serializer.data})
            user = GetUserSubmit.objects.all()
            serializer = GetUserSubmitSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to get profile details of user "}, status=status.HTTP_400_BAD_REQUEST)


class IGLNotificationAPI(generics.GenericAPIView):
    serializer_class = IGLNotificationSerializer

    def post(self, request):
        """Create List of record for IGLNotification
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = IGLNotificationSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to save user IGL notification"}, status=status.HTTP_400_BAD_REQUEST)


    def get(self, request, pk=None):
        """return a list of all Match for specific user IGLNotification
        :parm request:object to pass state,WHEN page/url requested by user.
        parm pk:pass to UserDetails id.
        """
        iGLNotification_id = pk
        if iGLNotification_id is not None:
            iGLNotification = IGLNotification.objects.get(id=iGLNotification_id)
            serializer = IGLNotificationSerializer(iGLNotification)
            return Response({"data": serializer.data})
        iGLNotification = IGLNotification.objects.all()
        serializer = IGLNotificationSerializer(iGLNotification, many=True)
        return Response({"data": serializer.data})

    def delete(self, request, pk):
        """delete a single record for IGLNotification,when request page/url requested the user
            :params pk pass the  IGLNotification record id"""
        game = IGLNotification(pk)
        game.delete()
        return Response({"msg": "IGL notification is deleted"})


class GlobalIndexHierarchyAPI(generics.GenericAPIView):
    serializer_class = GlobalIndexHierarchySerializer

    def post(self, request):
        """Create List of record for GlobalIndexHierarchyA
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = GlobalIndexHierarchySerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to save global index hierarchy details"}, status=status.HTTP_400_BAD_REQUEST)


    def get(self, request, pk=None):
        """return a list of all Match for specific user GlobalIndexHierarchy
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserDetails id.
            """
        user_id = pk
        if user_id is not None:
            globalIndexHierarchy = GlobalIndexHierarchy.objects.get(id=user_id)
            serializer = GlobalIndexHierarchySerializer(globalIndexHierarchy)
            return Response({"data": serializer.data})
        globalIndexHierarchy = GlobalIndexHierarchy.objects.all()
        serializer = GlobalIndexHierarchySerializer(globalIndexHierarchy, many=True)
        return Response({"data": serializer.data})


class GlobalIndexAPI(generics.GenericAPIView):
    serializer_class = GlobalIndexSerializer

    def post(self, request):
        """Create List of record for GlobalIndex
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = GlobalIndexSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to save user global index data"}, status=status.HTTP_400_BAD_REQUEST)


    def get(self, request, pk=None):
        """return a list of all Match for specific user GlobalIndex
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to GlobalIndex id.
            """
        user_id = pk
        if user_id is not None:
            globalIndex = GlobalIndex.objects.filter(user_id=user_id)
            serializer = GlobalIndexSerializer(globalIndex, many=True)
            return Response({"data": serializer.data})
        globalIndex = GlobalIndex.objects.all()
        serializer = GlobalIndexSerializer(globalIndex, many=True)
        return Response({"data": serializer.data})

    def delete(self, request, pk):
        """delete a single record for GlobalIndex,when request page/url requested the user
                      :params pk pass the  GlobalIndexA record id"""

        usercase = GlobalIndex(pk)
        usercase.delete()
        return Response({"msg": "global index is deleted"})


class PGIUserSubmitAPI(generics.GenericAPIView):
    serializer_class = PGIUserSubmitSerializer

    def post(self, request):
        """Create List of record for PGIUserSubmit
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = PGIUserSubmitSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Icon Information incoming!', e)
            return Response({"message": "Unable to create USER platform game and icon"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all Match for specific user PGIUserSubmit
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to PGIUserSubmit id.
            """
        user_id = pk
        try:
            if user_id is not None:
                user = PGIUserSubmit.objects.get(id=user_id)
                serializer = PGIUserSubmitSerializer(user)
                return Response({"data": serializer.data})
            user = PGIUserSubmit.objects.all()
            serializer = PGIUserSubmitSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Icon Information incoming!', e)
            return Response({"message": "Unable to get the user submit details"}, status=status.HTTP_400_BAD_REQUEST)


class UserIglNotificationViewAPI(APIView):
    # renderer_classes = [UserRenderer]
    serializer_class = UserIGLNotificationSerializer

    def get(self, request, pk=None):
        """return a list of all Match for specific user UserIglNotification
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserIglNotification
            """
        user_id = pk
        if user_id is not None:
            user = UserIGLNotification.objects.filter(user_id=user_id)
            if user.first() is None:
                return Response({"msg": "user details not found"},status=status.HTTP_400_BAD_REQUEST)
            serializer = UserIGLNotificationSerializer(user, many=True)
            return Response({"data": serializer.data})
        user = UserIGLNotification.objects.all()
        serializer = UserIGLNotificationSerializer(user, many=True)
        return Response({"data": serializer.data})

    def post(self, request):
        """Create List of record for UserIglNotification
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = UserIGLNotificationSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except:
            return Response({"message": "Unable to create IGL user_notification"}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """delete a single record for UserIglNotification,when request page/url requested the user
            :params pk pass the  UserIglNotification record id"""
        game = UserIGLNotification(pk)
        game.delete()
        return Response({"msg": "IGL user notification is deleted"})


class CompleteProfileAPI(generics.GenericAPIView):
    serializer_class = CreateProfileSerializer

    permission_classes = [IsAuthenticated]

    def post(self, request):
        """Create List of record for Match
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = CreateProfileSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to complete user profile "}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):

        """return a list of all Match for specific Match
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to Match id.
            """
        try:
            user_id = pk
            if user_id is not None:
                completeProfile = CompleteProfile.objects.filter(user_id=user_id)
                if completeProfile:
                    serializer = CompleteProfileSerializer(completeProfile, many=True)
                    return Response({"data": serializer.data})
                else:
                    return Response({"message": "Unable to get user details"})

            completeProfile = CompleteProfile.objects.all()
            serializer = CompleteProfileSerializer(completeProfile, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to get user complete profile details"}, status=status.HTTP_400_BAD_REQUEST)


class CompleteProfileUpdateAPI(generics.GenericAPIView):
    serializer_class = CompleteProfileUpdateSerializer

   # permission_classes = [IsAuthenticated]

    def post(self, request):
        """Create List of record for CompleteProfile
                :parm request:object to pass to state when request page/url requested the user
                 """
        try:
            serializer = CompleteProfileUpdateSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to complete user profile "}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all Match for specific CompleteProfile
                :parm request:object to pass state,WHEN page/url requested by user.
                parm pk:pass to CompleteProfile id.
                """
        user_id = pk
        try:
            if user_id is not None:
                completeProfile = CompleteProfile.objects.filter(user_id=user_id)
                serializer = CompletingProfileUpdateSerializer(completeProfile, many=True)
                return Response({"data": serializer.data})
            completeProfile = CompleteProfile.objects.all()
            serializer = CompletingProfileUpdateSerializer(completeProfile, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('match Information incoming!', e)
            return Response({"message": "Unable to get user complete profile details"}, status=status.HTTP_400_BAD_REQUEST)


    def patch(self, request, pk=id):
        """update a list of record for CompleteProfile,when request page/url requested the user
                       :params pk pass the  CompleteProfile record id"""
        user_id = pk
        try:
            if request:
                if user_id is not None:
                    update_platform = request.data['update_platform']
                    remove_platform = request.data['remove_platform']
                    update_game = request.data['update_game']
                    remove_game = request.data['remove_game']
                    for profile in CompleteProfile.objects.filter(user_id=user_id):
                        try:
                            if request:
                                if update_platform:
                                    for platform in update_platform:
                                        platform_id = Platform.objects.get(id=platform)
                                        profile.platform.add(platform_id.id)
                                        profile.save()

                                if remove_platform:
                                    for platform in remove_platform:
                                        platform_id = Platform.objects.get(id=platform)
                                        profile.platform.remove(platform_id.id)
                                        profile.save()

                        except Exception as e:
                            logging.info('Information incoming!', e)
                            return Response({"message": "Please enter valid platform details"})
                        try:
                            if request:
                                if update_game:
                                    for game in update_game:
                                        game_id = Game.objects.get(id=game)
                                        profile.games.add(game_id.id)
                                        profile.save()
                                if remove_game:
                                    for game in remove_game:
                                        game_id = Game.objects.get(id=game)
                                        profile.games.remove(game_id.id)
                                        profile.save()
                        except Exception as e:
                            logging.info('Information incoming!', e)
                            return Response({"message": "Please enter valid game details"})

            return Response({"message": "Profile is Successfully Updated"})
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to update user details"}, status=status.HTTP_400_BAD_REQUEST)



class GetAllFriendAPI(generics.GenericAPIView):
    """to get the GetAllFriend details with default GetAllFriend model based on ID"""
    serializer_class = GetAllFriendSerializer

    def get(self, request):

        """return a list of all Match for specific CompleteProfile
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to CompleteProfile id.
            """

        sender_objs = FriendRequest.objects.filter(Q(sender_id=request.user) | Q(receiver_id=request.user),
                                                    status=True).values_list('sender_id', flat=True).distinct()
        receiver_objs = FriendRequest.objects.filter(Q(sender_id=request.user) | Q(receiver_id=request.user),
                                                    status=True).values_list('receiver_id', flat=True).distinct()
        sender_users = User.objects.all().exclude(id__in=sender_objs)
        users = sender_users.exclude(id__in=receiver_objs)

        serializer = UserListSerializer(users, many=True, context={'request': request})
        return Response({"data": serializer.data})


class FriendRequestAPI(generics.GenericAPIView):
    serializer_class = FriendRequestSerializer

    # permission_classes = [IsAuthenticated]

    def post(self, request):
        """Create List of record for Match
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            receiver_obj = User.objects.get(id=int(request.data['receiver_id']))
            if not FriendRequest.objects.filter(sender_id=request.user, receiver_id=receiver_obj):
                serializer = FriendRequestSerializer(data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response({"data": serializer.data})
            else:
                return Response({"message": "Friends request already exists."},status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to perform action "}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):

        """return a list of all Match for specific Match
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to Match id.
            """
        try:
            user_id = pk
            if user_id is not None:
                user = FriendRequest.objects.get(id=user_id)
                if user:
                    serializer = FriendRequestSerializers(user, many=True)
                    return Response({"data": serializer.data})
                else:
                    return Response({"message": "Unable to get friend request"},status=status.HTTP_400_BAD_REQUEST)

            user = FriendRequest.objects.all()
            serializer = FriendRequestSerializers(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to send friend request"}, status=status.HTTP_400_BAD_REQUEST)


class AcceptFriendsRequest(generics.GenericAPIView):
    serializer_class = AcceptFriendsRequestSerializer

    # permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        """Create List of record for Match
            :parm request:object to pass to state when request page/url requested the user
             """

        # serializer = AcceptFriendsRequestSerializer(data=request.data)
        request_obj = FriendRequest.objects.get(pk=pk)

        if request.user == request_obj.receiver_id:
            request_obj.status = True
            request_obj.save()
            # For update friend request count
            user_id = User.objects.values("id").filter(email=request_obj.sender_id)[0]
            friend_request_value = UserBadges.objects.values('id', 'Friend_id').filter(user_id_id=user_id['id'])
            friend_count = len(FriendRequest.objects.filter(sender_id=request_obj.sender_id, status=True))
            if friend_count == 5 or friend_count == 10 or friend_count == 20:
                image_url = "friends_logos/" + f"{friend_count}" + "_friends.png"

                column_name = f"add{friend_count}"
                image_column_name = f"add{friend_count}_image"
                if not friend_request_value['Friend_id']:
                    FriendRequestQuery = Friends.objects.create(id=user_id['id'],
                                                                **{column_name: friend_count},
                                                                **{image_column_name: image_url})

                    FriendRequestQuery.save()

                    update_values = {'Friend_id': user_id['id']}
                    new_values = {'Friend_id': user_id['id'], "user_id_id": user_id['id']}
                    obj, created = UserBadges.objects.update_or_create(id=friend_request_value['id'],
                                                                       defaults=update_values)
                    if created:
                        obj.update(**new_values)

                else:
                    Friends.objects.values(column_name).filter(id=user_id['id']).update(
                        **{column_name: friend_count}, **{image_column_name: image_url})
                # end

            return Response({"data": AcceptFriendsRequestSerializer(request_obj).data})
        else:
            return Response({"message": "Request user not correct"},
                            status=status.HTTP_400_BAD_REQUEST)



class NotificationListAPI(generics.GenericAPIView):
    serializer_class = AcceptFriendsRequestSerializer
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """Create List of record for Match
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            request_objs = FriendRequest.objects.filter(receiver_id=request.user, status=False,)
            if request_objs:
                serializer = AcceptFriendsRequestSerializer(request_objs, many=True)
                return Response({"data": serializer.data})
            else:
                return Response({"message": "no data found"})

        except Exception as e:
            return Response({"message": "Unable to get Notification "}, status=status.HTTP_400_BAD_REQUEST)


class FriendListAPI(generics.GenericAPIView):
    serializer_class = AcceptFriendsRequestSerializer
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """Create List of record for Match
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            request_objs = FriendRequest.objects.filter(Q(sender_id=request.user) | Q(receiver_id=request.user), status=True)
            if request_objs:
                return Response({"data": AcceptFriendsRequestSerializer(request_objs, many=True).data})
            else:
                return Response({"message": "no data found"})

        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to get  Friend list "}, status=status.HTTP_400_BAD_REQUEST)

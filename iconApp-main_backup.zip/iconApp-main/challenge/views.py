from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import status, permissions, viewsets
from rest_framework import generics
from django_filters import rest_framework as filters
from django.utils import timezone
from django.shortcuts import render
from IGL_account.models import User
from .models import Challenge, ChallengeOutcome, CreateChallenge, OpenChallenge, DirectChallenge
#from .serializers import ChallengeSerializer, ChallengeResponseSerializer, ChallengeFilter, ChallengeOutcomeSerializer
from .serializers import ChallengeSerializer, CreateChallengeSerializer, ChallengeOutcomeSerializer, \
    CreateChallengeOutcomeSerializer, CreateNewChallengeSerializer, \
    CreatingNewChallengeSerializer, OpponentDetailsSerializer, \
    CreateOpenChallengeSerializer, OpenChallengeSerializer, CreateDirectChallengeSerializer, DirectChallengeSerializer
from iconApi.settings import default

# # Create your views here.

class UserChallengeAPI(generics.GenericAPIView):
    serializer_class = CreateChallengeSerializer

    def post(self, request):
        """Create List of record for challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreateChallengeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the user platform"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all challenges for on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserPlatform id.
            """
        user_id = pk

        try:
            if user_id is not None:
                challenge = Challenge.objects.get(id=user_id)
                serializer = ChallengeSerializer(challenge)
                return Response({"data": serializer.data})
            challenge  = Challenge.objects.all()
            serializer = ChallengeSerializer(challenge, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of user challenge "}, status=status.HTTP_400_BAD_REQUEST)


class UserChallengeResultAPI(generics.GenericAPIView):
    serializer_class = ChallengeOutcomeSerializer

    def post(self, request):
        """Create List of record for challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreateChallengeOutcomeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the user challenge result"})

    def get(self, request, pk=None):
        """return a list of all challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user_id = pk

        try:
            if user_id is not None:
                challengeOutcome = ChallengeOutcome.objects.get(id=user_id)
                serializer = ChallengeOutcomeSerializer(challengeOutcome)
                return Response({"data": serializer.data})
            challengeOutcome = ChallengeOutcome.objects.all()
            serializer = ChallengeOutcomeSerializer(challengeOutcome, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of challenge winner "}, status=status.HTTP_400_BAD_REQUEST)






class CreateNewChallengeAPI(generics.GenericAPIView):
    serializer_class = CreatingNewChallengeSerializer

    def post(self, request):
        """Create List of record for challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreatingNewChallengeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data, 'msg': ' Challenge created successfully'},
                                status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the new challenge"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all direct challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user_id = pk

        try:
            if user_id is not None:
                createChallenge = CreateChallenge.objects.filter(user_id=user_id)
                if createChallenge:
                    serializer = CreateNewChallengeSerializer(createChallenge, many=True)
                    return Response({"data": serializer.data})
            createChallenge = CreateChallenge.objects.all()
            serializer = CreateNewChallengeSerializer(createChallenge, many=True)
            return Response({"data": serializer.data}, status=status.HTTP_200_OK)
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of new created challenge"},
                            status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, pk=None):
        user_id = pk
        try:
            if user_id is not None:
                user = CreateChallenge.objects.get(id=user_id)
                user.status = request.data['status']
                user.save()
                return Response({"message": "status has been successfully updated"}, status=status.HTTP_200_OK)
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to update the status of challenge"}, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request, pk):
        """delete a single record for challenge,when request page/url requested the user
                      :params pk pass the  createChallenge record id"""

        challenge = CreateChallenge(pk)
        challenge.delete()
        return Response({"msg": "Challenge is deleted"})



class OpponentUserAPI(generics.GenericAPIView):
    serializer_class = OpponentDetailsSerializer

    def get(self, request, pk=None):

        """return a list of all direct challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user = User.objects.all()
        serializer = OpponentDetailsSerializer(user, many=True)
        return Response({"data": serializer.data},status=status.HTTP_200_OK)




class OpenChallengeAPI(generics.GenericAPIView):
    serializer_class = CreateOpenChallengeSerializer

    def post(self, request):
        """Create List of record for challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreateOpenChallengeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data, 'msg': ' Challenge created successfully'},
                                status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the new challenge"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all direct challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user_id = pk

        try:
            if user_id is not None:
                createChallenge = OpenChallenge.objects.get(id=user_id)
                serializer = OpenChallengeSerializer(createChallenge)
                return Response({"data": serializer.data}, status=status.HTTP_200_OK)
            createChallenge = OpenChallenge.objects.all()
            serializer = OpenChallengeSerializer(createChallenge, many=True)
            return Response({"data": serializer.data}, status=status.HTTP_200_OK)
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of new created challenge"},
                            status=status.HTTP_400_BAD_REQUEST)


class DirectChallengeAPI(generics.GenericAPIView):
    serializer_class = CreateDirectChallengeSerializer

    def post(self, request):
        """Create List of record for challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreateDirectChallengeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data, 'msg': ' Challenge created successfully'},
                                status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the new challenge"}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk=None):
        """return a list of all direct challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user_id = pk

        try:
            if user_id is not None:
                createChallenge = DirectChallenge.objects.get(id=user_id)
                serializer = DirectChallengeSerializer(createChallenge)
                return Response({"data": serializer.data}, status=status.HTTP_200_OK)
            createChallenge = DirectChallenge.objects.all()
            serializer = DirectChallengeSerializer(createChallenge, many=True)
            return Response({"data": serializer.data}, status=status.HTTP_200_OK)
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of new created challenge"},
                            status=status.HTTP_400_BAD_REQUEST)

